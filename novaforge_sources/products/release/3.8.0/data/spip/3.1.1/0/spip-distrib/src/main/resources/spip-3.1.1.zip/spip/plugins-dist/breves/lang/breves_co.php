<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=co
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Dispacci',

	// E
	'entree_breve_publiee' => 'Deve esse pubblicatu stu dispacciu ?', # MODIF
	'entree_texte_breve' => 'Testu di u dispacciu',

	// I
	'icone_breves' => 'Dispacci',
	'icone_ecrire_nouvel_article' => 'I dispacci cuntenuti in a rùbbrica',
	'icone_modifier_breve' => 'Mudificà u dispacciu',
	'icone_nouvelle_breve' => 'Scrive un nuvellu dispacciu',
	'info_1_breve' => '1 dispacciu',
	'info_breves' => 'U vostru situ aduprerà u sistema di dispacci ?',
	'info_breves_02' => 'Dispacci',
	'info_breves_valider' => 'Dispacci da cunvalidà',
	'info_gauche_numero_breve' => 'DISPACCIU NÙMERU', # MODIF
	'item_breve_proposee' => 'Dispacciu prupostu', # MODIF
	'item_breve_refusee' => 'INNO - Dispacciu rifiutatu', # MODIF
	'item_breve_validee' => 'IÈ   - Dispacciu cunvalidatu', # MODIF
	'item_non_utiliser_breves' => 'Ùn aduprà micca i dispacci',
	'item_utiliser_breves' => 'Aduprà i dispacci',

	// L
	'logo_breve' => 'LOGO DI U DISPACCIU', # MODIF

	// T
	'texte_breves' => 'I dispacci sò testi corti è sèmplici chì permettenu di mette in ligna nutizie assai in furia, è di gestisce una rivista di stampa, 
	un almanaccu d’evenimenti, ecc.',
	'titre_breve_proposee' => 'Dispacciu prupostu',
	'titre_breve_publiee' => 'Dispacciu pubblicatu',
	'titre_breve_refusee' => 'Dispacciu rifiutatu',
	'titre_breves' => 'I dispacci',
	'titre_langue_breve' => 'LINGUA DI U DISPACCIU', # MODIF
	'titre_page_breves' => 'Dispacci'
);

?>
