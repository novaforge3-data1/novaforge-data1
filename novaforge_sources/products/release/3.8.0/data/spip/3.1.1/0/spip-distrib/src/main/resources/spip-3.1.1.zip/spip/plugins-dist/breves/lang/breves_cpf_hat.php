<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=cpf_hat
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Tinouvèl yo',

	// E
	'entree_breve_publiee' => 'Eske tinouvèl-la gen pibliye ?', # MODIF
	'entree_texte_breve' => 'Tèks pou tinouvèl-la',

	// I
	'icone_breves' => 'Tinouvèl yo',
	'icone_ecrire_nouvel_article' => 'Tinouvèl yo andan ribrik la',
	'icone_modifier_breve' => 'Chanje tinouvèl',
	'icone_nouvelle_breve' => 'Ekri yon nouvo tinouvèl',
	'info_1_breve' => '1 tinouvèl',
	'info_breves' => 'Eske w sit ap itlize sistèm tinouvèl yo?',
	'info_breves_02' => 'Tinouvèl yo',
	'info_breves_valider' => 'Tinouvèl yo ki tann yon komandè konfime',
	'info_gauche_numero_breve' => 'TINOUVÈL NIMÈWO', # MODIF
	'item_breve_proposee' => 'Tinouvèl pwopoze pou parèt ', # MODIF
	'item_breve_refusee' => 'NON - tinouvèl ki refize', # MODIF
	'item_breve_validee' => 'WI - Tinouvèl ki konfime', # MODIF
	'item_non_utiliser_breves' => 'Itilize pa tinouvèl',
	'item_utiliser_breves' => 'Itilize tinouvel yo',

	// L
	'logo_breve' => 'LOGO TINOUVÈL', # MODIF

	// T
	'texte_breves' => 'Ti-nouvèl yo se ti tèks senp ki pèmè w fè parèt kèk ti enfòmasyon taptap, osnon debouye w ek yon revi-laprès, ek mèm yon kalandrye pou anonse kisa moun kap soutni.',
	'titre_breve_proposee' => 'Tinouvèl pwopoze pou parèt',
	'titre_breve_publiee' => 'Tinouvèl ki pibliye an liy',
	'titre_breve_refusee' => 'Tinouvèl ki refize',
	'titre_breves' => 'Tinouvèl yo',
	'titre_langue_breve' => 'LALANNG TINOUVÈL-LA', # MODIF
	'titre_page_breves' => 'Tinouvèl yo'
);

?>
