<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=fon
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Xogbè kléwun',

	// E
	'entree_breve_publiee' => 'mī ɖɔ dó xàsádómɛ à', # MODIF
	'entree_texte_breve' => 'wěmá kléwun',

	// I
	'icone_breves' => 'xó kléwún ',
	'icone_ecrire_nouvel_article' => 'xó kléwún ɖé lò àkpáxwé é lɔ mɛ ɔ',
	'icone_modifier_breve' => 'mi vɔ ɖyɔ xókléwún',
	'icone_nouvelle_breve' => 'mi vɔ xó kléwún ɖêvó wlán',
	'info_1_breve' => 'xó kléwún ɖòkpó',
	'info_breves' => 'gblogblojí mi tɔn nɔ yí xó kléwún á?',
	'info_breves_02' => 'xó kléwún lɛ',
	'info_breves_valider' => 'xó kléwún ê nà sɔkɛná',
	'info_gauche_numero_breve' => 'xó kléwûn nùmɛló', # MODIF
	'item_breve_proposee' => 'ɖɔ xó kléwún', # MODIF
	'item_breve_refusee' => 'Éwó - yé gbɛ xó kléwún', # MODIF
	'item_breve_validee' => 'Núgbó wɛ - yé sɔ kɛn nu xó kléwún', # MODIF
	'item_non_utiliser_breves' => 'mi má zán xókléwún lɛ',
	'item_utiliser_breves' => 'mi zán xó kléwún lɛ',

	// L
	'logo_breve' => 'sɔsí xó kléwún ɔ tɔn', # MODIF

	// T
	'texte_breves' => 'bɔ yé nɔ zɔn bɔ xó lɛ nɔ yí àtɛjí gànmɛgànmɛ...',
	'titre_breve_proposee' => 'xó kléwún yé sɔ jó',
	'titre_breve_publiee' => 'xó kléwún yé sɔ xlɛ',
	'titre_breve_refusee' => 'xó kléwún yê gbɛ ɔ ',
	'titre_breves' => 'xó kléwún ',
	'titre_langue_breve' => 'Gbèzán xó kléwún ɔ tɔn', # MODIF
	'titre_page_breves' => 'xó kléwún lɛ'
);

?>
