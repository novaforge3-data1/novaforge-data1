<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=hr
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Vijesti',

	// E
	'entree_breve_publiee' => 'Da li se ova vijest može objaviti?', # MODIF
	'entree_texte_breve' => 'sadržaj (tekst) vijesti',

	// I
	'icone_breves' => 'vijesti',
	'icone_nouvelle_breve' => 'napisati novu vijest',
	'info_breves_02' => 'vijesti',
	'info_breves_valider' => 'vijesti za provjeru',
	'item_breve_proposee' => 'predložena vijest', # MODIF
	'item_breve_refusee' => 'NE - vijest odbačena', # MODIF
	'item_breve_validee' => 'DA - vijest odobrena', # MODIF

	// T
	'titre_breve_proposee' => 'podnešena vijest',
	'titre_breve_publiee' => 'objavljena vijest',
	'titre_breve_refusee' => 'odbačena vijest'
);

?>
