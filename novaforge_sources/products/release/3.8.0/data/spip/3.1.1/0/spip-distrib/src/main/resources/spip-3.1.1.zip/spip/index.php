<?php
	# appel SPIP
	include('spip.php');
