<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=ay
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Jisk’aptatanaka',

	// E
	'entree_breve_publiee' => '¿Aka jisk’aptat yatiysnat?
', # MODIF
	'entree_texte_breve' => 'Jisk’aptata sawu',

	// I
	'icone_breves' => 'Jisk’aptatanaka',
	'icone_ecrire_nouvel_article' => 'Aka t’aqat jisk’aptatanakaxa ',
	'icone_modifier_breve' => 'Aka jisk’aptata mayjt’ayaña',
	'icone_nouvelle_breve' => 'Machaq jiskht’aptata',
	'info_1_breve' => '1 jisk’aptata',
	'info_breves' => 'Jisk’aptatanak apnaqaw apnaqasmaw',
	'info_breves_02' => 'Jisk’aptatanaka',
	'info_breves_valider' => 'Jisk’aptatanak iyaw sañataki',
	'info_gauche_numero_breve' => 'Jisk’aptata', # MODIF
	'item_breve_proposee' => 'Jisk’aptat amtawi', # MODIF

	// T
	'titre_breve_proposee' => 'Jisk’aptat amtata',
	'titre_breve_publiee' => 'Jisk’aptat iyaw sata',
	'titre_breve_refusee' => 'Jisk’aptat janiw sata'
);

?>
