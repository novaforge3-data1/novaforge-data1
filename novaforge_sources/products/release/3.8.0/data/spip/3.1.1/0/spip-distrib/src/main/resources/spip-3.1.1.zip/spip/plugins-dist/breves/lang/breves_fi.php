<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=fi
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'breves' => 'Uutisia',

	// E
	'entree_breve_publiee' => 'Tulisiko tämä uutisotsikko julkaista?', # MODIF
	'entree_texte_breve' => 'Uutisotsikon teksti',

	// I
	'icone_breves' => 'Uuutisia',
	'icone_ecrire_nouvel_article' => 'Uutisia tässä lohkossa',
	'info_1_breve' => '1 uutisotsikko',
	'info_breves' => 'Käyttääkö sivustosi uutisjärjestelmää?',
	'info_breves_02' => 'Uutisia',
	'info_breves_valider' => 'Hyväksyttäviä uutisotsikoita',
	'item_utiliser_breves' => 'Käytä uutisia',

	// T
	'titre_langue_breve' => 'UUTISOTSIKON KIELI', # MODIF
	'titre_page_breves' => 'Uutisia'
);

?>
