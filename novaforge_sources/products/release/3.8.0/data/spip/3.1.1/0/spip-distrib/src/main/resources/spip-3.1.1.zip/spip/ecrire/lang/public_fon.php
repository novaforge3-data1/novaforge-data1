<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/public?lang_cible=fon
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'accueil_site' => 'Hɔntogbo', # MODIF
	'articles' => 'Wekpa lɛ̂',
	'articles_auteur' => 'Nyɔwlantɔ é lɔ sin wekpa lɛ̂',
	'articles_populaires' => 'wekpa lɛ̂  ê to bi tùn yé',
	'articles_rubrique' => 'wekpa ɖiɖɛ é lɔ tɔn',
	'aucun_article' => 'wekpa ɖē̄  do gesi é lɔ ji a ',
	'aucun_auteur' => 'Nyɔwlantɔ ɖē̄  do  gesi é lɔ ji a ',
	'aucun_site' => 'Gblogbloji ɖē̄  do  gesi é lɔ ji a',
	'aucune_breve' => 'Xogbè kléwun ɖē̄  do  gesi é lɔ ji a',
	'aucune_rubrique' => 'ɖiɖɛ ɖē̄ do gesi é lɔ ji a ',
	'autres_breves' => 'Xogbè kléwun de vo',
	'autres_groupes_mots_clefs' => 'Xota bɛ dokpɔ lɛ̂ ',
	'autres_sites' => 'Gblogbloji ɖē̄ vo lɛ̂',

	// B
	'bonjour' => 'kwabɔ   ',

	// C
	'commenter_site' => 'wlɔkànnú xo lɛ̂',

	// D
	'date' => 'Azan',
	'dernier_ajout' => 'Gɔna gùdogùdotɔn',
	'dernieres_breves' => 'Xogbè kléwun gùdogùdotɔn',
	'derniers_articles' => 'Wekpa gùdogùdotɔn',
	'derniers_commentaires' => 'ɖɛtitɛ gùdogùdotɔn',
	'derniers_messages_forum' => 'whɛn gùdogùdotɔn yē ɖɔdotoji',

	// E
	'edition_mode_texte' => 'winwlanmɛ',
	'en_reponse' => 'ɖogbèyiyi mɛ nu :',
	'en_resume' => 'ɖo xo kléwun mɛ ɔ',
	'envoyer_message' => 'Sɛ wɛn do ',
	'espace_prive' => 'tɛnkandovo',

	// H
	'hierarchie_site' => 'Tito gblogbloji ɔ tɔn',

	// J
	'jours' => 'Azan lɛ̂',

	// M
	'meme_auteur' => 'Nyɔwlantɔ ɖokpo ɔ',
	'meme_rubrique' => 'ɖo akpaxwé ɖokpo ɔ mɛ',
	'memes_auteurs' => 'Nyɔwlantɔ ɖokpo lɛ̂',
	'message' => 'Wɛn',
	'messages_forum' => 'wɛn pkékplé ɔ tɔn lê', # MODIF
	'messages_recents' => 'wɛn gùdógùdotɔn pkékplé ɔ tɔn lê',
	'mots_clefs' => 'xótá lɛ̂',
	'mots_clefs_meme_groupe' => 'xótá akpa ɖokpó ɔ lɛ̂ tɔn',

	// N
	'navigation' => 'nukéjékéjé',
	'nom' => 'nyíkɔ',
	'nouveautes' => 'Nu yɔyɔ lɛ̂',
	'nouveautes_web' => 'Nu yɔyɔ lɛ̂  e ɖo atɛ ɔ jí ɔ',
	'nouveaux_articles' => 'Wékpa yɔyɔ lɛ̂',
	'nouvelles_breves' => 'wɛn kléwun lɛ̂',

	// P
	'page_precedente' => 'Wékpa e wai',
	'page_suivante' => 'Wékpa e bɔɖéu',
	'par_auteur' => 'Gbɔn',
	'participer_site' => 'Mì ɖè mì ɖé xlɛ bó ná  siwu kɛ nù dó walɔ gblogblojí ɔ tɔn  enɛ gúdo ɔ mì  singan    sɔ wékpa mi tɔn lɛ̂ sɛ  dó. ɖo mɔ ɔ, mì nà sɛ gbètàkwin ná ná gbè bɔ mì ɖo tàfɔ atɛ ɔ jí  zɔnɖokpo e.',
	'plan_site' => 'titomɛ gblogbloji ɔ tɔn ',
	'popularite' => 'Nukún ɖéjí',
	'poster_message' => 'sɛ wɛn do',
	'proposer_site' => 'Nu mi do gblogblojí ɖé ɔ  Mì siwu zé gɔ ná akpa é lɔ ',

	// R
	'repondre_article' => 'ɖò sin nu wékpa e lɔ',
	'repondre_breve' => 'ɖò sin nu xó klewun é lɔ',
	'resultats_recherche' => 'Gbètakɛn nu do biba tɔn lɛ̂',
	'retour_debut_forums' => 'kɔlɛ sɔ yì  kplékplé sin bibɛ',
	'rubrique' => 'Akpa ',
	'rubriques' => 'Akpa lɛ',

	// S
	'signatures_petition' => 'alɔdowemamɛ lɛ',
	'site_realise_avec_spip' => 'Kpo alɔgɔ Supipu tɔn kpó wɛ gblogblojí ɔ nyí wiwa',
	'sites_web' => 'Atɛ lɛ̂',
	'sous_rubriques' => 'Akpa xwé',
	'suite' => 'Bɔ ɖé wu tɔn',
	'sur_web' => 'ɖò atɛ ɔ  jì',
	'syndiquer_rubrique' => 'Zê aceji do akpa é lɔ jí',
	'syndiquer_site' => 'acéjínínɔ',

	// T
	'texte_lettre_information' => 'Xojlawemá gblogbloji ɔ tɔn ɖiè',
	'texte_lettre_information_2' => 'Xojlawemá é lɔɔ nɔ cian wékpa kpodó xó klewun ɖɔ̀dotojí xoxo lɛ̂', # MODIF

	// V
	'ver_imprimer' => 'Zin wema',
	'voir_en_ligne' => 'kpɔn Gblogbloji',
	'voir_squelette' => 'Sɛ titomɛ wema élɔ tɔn do '
);

?>
