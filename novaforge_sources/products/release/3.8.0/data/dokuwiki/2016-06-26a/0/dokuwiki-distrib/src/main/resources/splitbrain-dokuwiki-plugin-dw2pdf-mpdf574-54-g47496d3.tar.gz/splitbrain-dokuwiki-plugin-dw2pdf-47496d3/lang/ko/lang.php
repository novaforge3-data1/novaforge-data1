<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 * @author wkdl <chobkwon@gmail.com>
 */
$lang['export_pdf_button']     = 'PDF로 내보내기';
$lang['needtitle']             = '제목을 제공하세요.';
$lang['needns']                = '존재하는 이름공간을 제공하세요.';
$lang['empty']                 = '아직 선택한 페이지가 없습니다.';
$lang['tocheader']             = '목차';
$lang['export_ns']             = '"%s:" 이름공간을 %s.pdf 파일로 내보내기';
