<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Rodrigo Pimenta <rodrigo.pimenta@gmail.com>
 */
$lang['export_pdf_button']     = 'Exportar para PDF';
$lang['needtitle']             = 'Favor fornecer um título.';
$lang['needns']                = 'Favor fornecer um namespace já existente.';
$lang['empty']                 = 'Você não selecionou páginas ainda.';
