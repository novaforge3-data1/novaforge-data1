<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Søren Birk <soer9648@eucl.dk>
 * @author Jacob Palm <mail@jacobpalm.dk>
 */
$lang['export_pdf_button']     = 'Eksportér til PDF';
$lang['needtitle']             = 'Angiv venligst en titel.';
$lang['needns']                = 'Angiv venligst et eksisterende navnerum.';
$lang['empty']                 = 'Du har endnu ikke valgt sider.';
$lang['tocheader']             = 'Indholdsfortegnelse';
