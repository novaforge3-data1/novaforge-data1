<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author oott123 <ip.192.168.1.1@qq.com>
 */
$lang['export_pdf_button']     = '导出 PDF';
$lang['empty'] = "您还没有选择的页面。";
$lang['needtitle'] = "需要指定标题";
