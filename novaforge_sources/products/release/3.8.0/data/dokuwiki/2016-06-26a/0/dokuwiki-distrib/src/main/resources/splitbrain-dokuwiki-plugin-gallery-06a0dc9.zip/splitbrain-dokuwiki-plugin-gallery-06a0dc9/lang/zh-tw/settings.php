<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author tsangho <ou4222@gmail.com>
 */
$lang['thumbnail_width']       = '縮圖的寬度';
$lang['thumbnail_height']      = '縮圖的高度';
$lang['image_width']           = '圖像寬度';
$lang['image_height']          = '圖像高度';
$lang['cols']                  = '每一列的圖像數';
$lang['sort']                  = '相簿圖像要如何排序?';
$lang['sort_o_file']           = '依檔名排序';
$lang['sort_o_mod']            = '依建檔日期排序';
$lang['sort_o_date']           = '依EXIF日期排序';
$lang['sort_o_title']          = '依EXIF標題排序';
$lang['options']               = '額外的相簿預設選項';
