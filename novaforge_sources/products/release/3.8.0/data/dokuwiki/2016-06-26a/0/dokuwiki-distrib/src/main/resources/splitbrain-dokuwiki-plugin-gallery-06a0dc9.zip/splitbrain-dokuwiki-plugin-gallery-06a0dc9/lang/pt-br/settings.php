<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Juliano Marconi Lanigra <juliano.marconi@gmail.com>
 */
$lang['thumbnail_width']       = 'Largura da imagem miniatura';
$lang['thumbnail_height']      = 'Altura da imagem miniatura';
$lang['image_width']           = 'Largura da imagem';
$lang['image_height']          = 'Altura da imagem';
$lang['cols']                  = 'Imagens por linha';
$lang['sort']                  = 'Como ordenar as imagens da galeria';
$lang['sort_o_file']           = 'ordenar por nome do arquivo';
$lang['sort_o_mod']            = 'ordenar por data do arquivo';
$lang['sort_o_date']           = 'ordenar por data EXIF';
$lang['sort_o_title']          = 'ordenar por título EXIF';
$lang['options']               = 'Opções padrão da galeria adicional';
