<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Juergen-aus-Koeln <h-j-schuemmer@web.de>
 */
$lang['export_pdf_button']     = 'PDF exportieren';
$lang['needtitle']             = 'Bitte Titel angeben!';
$lang['needns']                = 'Bitte geben Sie einen vorhandenen Namensraum an.';
$lang['empty']                 = 'Sie haben noch keine Seiten gewählt.';
$lang['tocheader']             = 'Inhaltsverzeichnis';
$lang['export_ns']             = 'Exportiere Namensraum "%s:" in Datei %s.pdf';
