<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Thomas Templin <templin@gnuwhv.de>
 */
$lang['export_pdf_button']     = 'PDF exportieren';
