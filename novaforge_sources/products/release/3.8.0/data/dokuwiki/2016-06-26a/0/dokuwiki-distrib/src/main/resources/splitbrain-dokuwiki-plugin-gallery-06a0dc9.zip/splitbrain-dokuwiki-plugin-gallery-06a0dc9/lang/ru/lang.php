<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['pages']                 = 'Страницы галереи:';
$lang['js']['addgal']          = 'Добавить пространство имён как галерею';
