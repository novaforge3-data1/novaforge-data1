<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author oott123 <ip.192.168.1.1@qq.com>
 */
$lang['pages']                 = '相册页面';
$lang['js']['addgal']          = '将命名空间添加为相册';
