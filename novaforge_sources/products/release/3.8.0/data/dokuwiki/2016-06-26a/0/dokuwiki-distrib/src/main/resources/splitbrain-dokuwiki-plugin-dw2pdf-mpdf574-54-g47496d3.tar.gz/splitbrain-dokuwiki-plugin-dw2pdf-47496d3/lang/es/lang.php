<?php

$lang['export_pdf_button'] = "Exportar a PDF";
$lang['needtitle']         = "Por favor proporcione un título.";
$lang['needns']            = "Por favor proporcione un nombre de espacio existente.";
$lang['empty']             = "No tiene páginas seleccionadas aún.";
$lang['tocheader']         = "Tabla de Contenidos";
