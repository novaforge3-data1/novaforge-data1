<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Christopher Schive <chschive@frisurf.no>
 * @author Daniel Raknes <rada@jbv.no>
 */
$lang['export_pdf_button']     = 'Eksporter til PDF';
$lang['needtitle']             = 'Legg inn en tittel.';
$lang['needns']                = 'Legg inn et eksisterende navnerom.';
$lang['empty']                 = 'Du har ikke valgt noen sider ennå.';
$lang['tocheader']             = 'Innholdsfortegnelse';
$lang['export_ns']             = 'Eksporter navnerom "%s:" til filen %s.pdf';
