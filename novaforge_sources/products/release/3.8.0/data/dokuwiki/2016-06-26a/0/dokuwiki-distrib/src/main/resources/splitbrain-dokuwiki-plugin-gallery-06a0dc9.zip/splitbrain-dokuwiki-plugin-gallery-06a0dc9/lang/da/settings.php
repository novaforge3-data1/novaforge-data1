<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Soren Birk <soer9648@hotmail.com>
 */
$lang['thumbnail_width']       = 'Miniaturebillede bredde';
$lang['thumbnail_height']      = 'Miniaturebillede højde';
$lang['image_width']           = 'Billede bredde';
$lang['image_height']          = 'Billede højde';
$lang['cols']                  = 'Billeder per række';
$lang['sort']                  = 'Sortér galleribilleder efter';
$lang['sort_o_file']           = 'sortér efter filnavn';
$lang['sort_o_mod']            = 'sortér efter fildato';
$lang['sort_o_date']           = 'sortér efter EXIF dato';
$lang['sort_o_title']          = 'sortér efter EXIF titel';
$lang['options']               = 'Yderligere galleri-standardindstillinger';
