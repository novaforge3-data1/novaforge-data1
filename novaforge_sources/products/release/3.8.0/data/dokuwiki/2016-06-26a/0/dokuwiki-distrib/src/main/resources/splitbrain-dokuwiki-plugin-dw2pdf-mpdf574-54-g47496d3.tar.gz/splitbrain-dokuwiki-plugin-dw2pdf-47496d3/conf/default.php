<?php
$conf['pagesize']         = 'A4';
$conf['orientation']      = 'portrait';
$conf['doublesided']      = 1;
$conf['toc']              = 0;
$conf['toclevels']        = '';
$conf['maxbookmarks']     = 5;
$conf['template']         = 'default';
$conf['output']           = 'file';
$conf['usecache']         = 1;
$conf['usestyles']        = '';
$conf['qrcodesize']       = '120x120';
$conf['showexportbutton'] = 1;
