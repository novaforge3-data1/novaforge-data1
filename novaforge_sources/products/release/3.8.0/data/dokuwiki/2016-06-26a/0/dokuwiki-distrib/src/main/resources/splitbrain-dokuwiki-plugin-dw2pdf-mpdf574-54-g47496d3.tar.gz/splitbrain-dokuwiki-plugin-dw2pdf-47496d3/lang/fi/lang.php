<?php

$lang['export_pdf_button'] = "Tee PDF";
$lang['needtitle']         = "Anna otsikko.";
$lang['needns']            = "Anna olemassa oleva namespace.";
$lang['empty']             = "Valitse ensin sivu.";
