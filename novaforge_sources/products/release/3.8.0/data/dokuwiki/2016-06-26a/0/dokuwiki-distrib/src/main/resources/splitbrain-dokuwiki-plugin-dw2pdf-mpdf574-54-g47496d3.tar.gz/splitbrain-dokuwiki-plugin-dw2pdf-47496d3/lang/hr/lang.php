<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['export_pdf_button']     = 'Izvoz u PDF';
$lang['needtitle']             = 'Molim unesite naslov';
$lang['needns']                = 'Molim navedite postojeći imenski prostor.';
$lang['empty']                 = 'Nemate još odabranih stranica.';
$lang['tocheader']             = 'Sadržaj';
$lang['export_ns']             = 'Izvoz imenskog prostora "%s:" u %s.pdf';
