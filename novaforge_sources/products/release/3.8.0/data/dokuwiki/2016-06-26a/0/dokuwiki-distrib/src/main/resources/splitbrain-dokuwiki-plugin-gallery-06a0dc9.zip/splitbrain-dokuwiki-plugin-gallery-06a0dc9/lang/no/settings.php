<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Daniel Raknes <rada@jbv.no>
 */
$lang['thumbnail_width']       = 'Miniatyrbilde bredde';
$lang['thumbnail_height']      = 'Miniatyrbilde høyde';
$lang['image_width']           = 'Bildebredde';
$lang['image_height']          = 'Bildehøyde';
$lang['cols']                  = 'Bilder pr. rad';
$lang['sort']                  = 'Sortering av bildene';
$lang['sort_o_file']           = 'sorter etter filnavn';
$lang['sort_o_mod']            = 'sorter etter fildato';
$lang['sort_o_date']           = 'sorter etter EXIF dato';
$lang['sort_o_title']          = 'sorter etter EXIT tittel';
$lang['options']               = 'Andre standardvalg for bildearkivet';
