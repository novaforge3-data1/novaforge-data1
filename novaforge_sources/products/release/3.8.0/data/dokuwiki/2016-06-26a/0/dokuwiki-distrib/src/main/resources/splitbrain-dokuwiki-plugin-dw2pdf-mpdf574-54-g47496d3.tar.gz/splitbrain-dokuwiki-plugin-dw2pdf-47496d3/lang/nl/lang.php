<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Gerrit Uitslag <klapinklapin@gmail.com>
 * @author Wouter Wijsman <wwijsman@live.nl>
 * @author Peter van Diest <peter.van.diest@xs4all.nl>
 */
$lang['export_pdf_button']     = 'Exporteren naar PDF';
$lang['needtitle']             = 'Er moet een titel ingevuld worden';
$lang['needns']                = 'Geef een bestaande namespace.';
$lang['empty']                 = 'Er zijn nog geen pagina\'s geselecteerd.';
$lang['tocheader']             = 'Inhoudsopgave';
$lang['export_ns']             = 'Exporteren namespace "%s:" naar bestand %s.pdf';
