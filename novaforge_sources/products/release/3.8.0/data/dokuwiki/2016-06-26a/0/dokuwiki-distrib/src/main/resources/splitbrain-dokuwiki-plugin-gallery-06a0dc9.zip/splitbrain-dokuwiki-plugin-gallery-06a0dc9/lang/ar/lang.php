<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ali Almlfy <Almlfy@hotmail.com>
 */
$lang['pages']                 = 'صفحات المعرض ';
$lang['js']['addgal']          = 'أضف نطاق كامعرض ';
