<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Juliano Marconi Lanigra <juliano.marconi@gmail.com>
 */
$lang['pages']                 = 'Páginas da galeria:';
$lang['js']['addgal']          = 'Adicionar domínio como galeria';
