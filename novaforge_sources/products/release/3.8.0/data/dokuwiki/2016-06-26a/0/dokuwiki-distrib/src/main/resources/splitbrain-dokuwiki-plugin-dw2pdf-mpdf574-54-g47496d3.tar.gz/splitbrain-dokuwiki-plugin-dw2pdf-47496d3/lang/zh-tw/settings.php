<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author lioujheyu <lioujheyu@gmail.com>
 */
$lang['output']                = 'PDF將以何種方式呈現在使用者之前？';
$lang['output_o_browser']      = '以瀏覽器開啟';
$lang['output_o_file']         = '下載PDF檔案';
$lang['orientation']           = '頁面方向';
$lang['orientation_o_portrait'] = '直式';
$lang['orientation_o_landscape'] = '橫式';
$lang['showexportbutton']      = '顯示輸出PDF按鈕 (只在模板支援時才顯示)';
