<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 * @author Robert Bogenschneider <robog@gmx.de>
 */
$lang['export_pdf_button']     = 'Eksporti al PDF';
$lang['needtitle']             = 'Bonvolu indiki titolon.';
$lang['needns']                = 'Bv. indiki ekzistantan nomspacon.';
$lang['empty']                 = 'Vi ankoraŭ ne selektis paĝojn.';
$lang['tocheader']             = 'Enhavtabelo';
