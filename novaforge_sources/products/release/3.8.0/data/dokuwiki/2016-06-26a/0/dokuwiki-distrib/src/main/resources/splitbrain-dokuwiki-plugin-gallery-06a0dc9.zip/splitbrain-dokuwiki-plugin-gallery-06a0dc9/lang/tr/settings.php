<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Shiliew <siskyblue@hotmail.com>
 * @author ilker Rifat Kapaç <irifat@gmail.com>
 */
$lang['thumbnail_width']       = 'Küçük resim genişliği';
$lang['thumbnail_height']      = 'Küçük resim yüksekliği';
$lang['image_width']           = 'Resim genişliği';
$lang['image_height']          = 'Resim yüksekliği';
$lang['cols']                  = 'Satır başına görüntü sayısı';
$lang['sort']                  = 'Sergi resimleri nasıl sıralansın';
$lang['sort_o_file']           = 'Dosya adına göre sırala';
$lang['sort_o_mod']            = 'Dosya tarihine göre sıralama';
$lang['sort_o_date']           = 'EXIF tarihine göre sırala';
$lang['sort_o_title']          = 'EXIF başlığına göre sırala';
$lang['options']               = 'İlave serginin varsayılan seçenekleri';
