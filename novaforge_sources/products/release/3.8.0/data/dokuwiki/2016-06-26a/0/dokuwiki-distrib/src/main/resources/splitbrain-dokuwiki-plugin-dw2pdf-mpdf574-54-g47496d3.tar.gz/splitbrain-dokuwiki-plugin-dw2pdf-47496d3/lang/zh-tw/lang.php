<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author lioujheyu <lioujheyu@gmail.com>
 */
$lang['export_pdf_button']     = '輸出PDF檔案';
$lang['needtitle']             = '請提供一個抬頭名稱';
$lang['needns']                = '請提供一個以存在的命名空間';
$lang['empty']                 = '你尚未選擇頁面。';
