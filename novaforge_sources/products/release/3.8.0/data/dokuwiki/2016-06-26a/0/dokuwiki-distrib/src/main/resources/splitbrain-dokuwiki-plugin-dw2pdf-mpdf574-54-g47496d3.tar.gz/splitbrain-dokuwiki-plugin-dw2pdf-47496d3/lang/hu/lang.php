<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Marina Vladi <deldadam@gmail.com>
 * @author Imre Nagy <crash2@freemail.hu>
 */
$lang['export_pdf_button']     = 'Exportálás PDF-be';
$lang['tocheader']             = 'Tartalomjegyzék';
