<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['pages']                 = '갤러리 페이지:';
$lang['js']['addgal']          = '갤러리로 이름공간 추가';
