<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['export_pdf_button']     = 'PDF の出力';
$lang['needtitle']             = '題名を入力して下さい。';
$lang['needns']                = '名前空間を入力して下さい。';
$lang['empty']                 = 'ページを選択していません。';
$lang['tocheader']             = '目次';
$lang['export_ns']             = '名前空間 "%s:" を %s.pdf というファイル名で出力';
