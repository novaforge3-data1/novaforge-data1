<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aleksandr Selivanov <alexgearbox@gmail.com>
 */
$lang['thumbnail_width']       = 'Ширина миниатюры изображения';
$lang['thumbnail_height']      = 'Высота миниатюры изображения';
$lang['image_width']           = 'Ширина изображения';
$lang['image_height']          = 'Высота изображения';
$lang['cols']                  = 'Изображения в ряд';
$lang['sort']                  = 'Как сортировать изображения в галерее';
$lang['sort_o_file']           = 'сортировать по имени файла';
$lang['sort_o_mod']            = 'сортировать по дате файла';
$lang['sort_o_date']           = 'сортировать по EXIF-дате';
$lang['sort_o_title']          = 'сортировать по EXIF-заголовку';
$lang['options']               = 'Дополнительные опции';
