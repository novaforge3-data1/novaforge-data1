<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Andreas Gohr <andi@splitbrain.org>
 */
$lang['pages']                 = 'Galerie-Seiten:';
$lang['js']['addgal']          = 'Namensraum als Galerie hinzufügen';
