<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['thumbnail_width']       = 'Bildeta larĝeco';
$lang['thumbnail_height']      = 'Bildeta alteco';
$lang['image_width']           = 'Bildlarĝeco';
$lang['image_height']          = 'Bildalteco';
$lang['cols']                  = 'Bildoj po vico';
$lang['sort']                  = 'Kiel ordigi la galeribildojn';
$lang['sort_o_file']           = 'ordigi per dosier-nomo';
$lang['sort_o_mod']            = 'ordigi per dosier-dato';
$lang['sort_o_date']           = 'ordigi per EXIF-dato';
$lang['sort_o_title']          = 'ordigi per EXIF-titolo';
$lang['options']               = 'Aldonaj galeriaj standardaj opcioj';
