<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['export_pdf_button']     = 'Esporta in PDF';
$lang['needtitle']             = 'Per favore fornire un titolo.';
$lang['empty']                 = 'Non hai ancora selzionato delle pagine.';
$lang['tocheader']             = 'Sommario';
