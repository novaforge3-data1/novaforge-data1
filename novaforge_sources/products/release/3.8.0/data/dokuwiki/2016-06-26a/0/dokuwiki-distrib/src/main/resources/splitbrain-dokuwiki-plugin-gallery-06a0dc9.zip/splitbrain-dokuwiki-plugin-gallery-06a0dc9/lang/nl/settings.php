<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@outlook.com>
 */
$lang['thumbnail_width']       = 'Breedte van het miniatuur beeld';
$lang['thumbnail_height']      = 'Hoogte van het miniatuur beeld';
$lang['image_width']           = 'Beeld breedte';
$lang['image_height']          = 'Beeld hoogte';
$lang['cols']                  = 'Aantal beelden per rij';
$lang['sort']                  = 'Hoe de beeldreeks sorteren';
$lang['sort_o_file']           = 'sorteren op bestandsnaam';
$lang['sort_o_mod']            = 'sorteren op bestandsdatum';
$lang['sort_o_date']           = 'sorteren op EXIF datum';
$lang['sort_o_title']          = 'sorteren op EXIF titel';
$lang['options']               = 'Bijkomende beeldreeks verstek opties';
