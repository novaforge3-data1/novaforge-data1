<?php

$lang['export_pdf_button'] = "Export to PDF";
$lang['needtitle']         = "Please provide a title.";
$lang['needns']            = "Please provide an existing namespace.";
$lang['empty']             = "You don't have pages selected yet.";
$lang['tocheader']         = "Table of Contents";
$lang['export_ns']         = 'Export namespace "%s:" to file %s.pdf';
