<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['thumbnail_width']       = 'Lled bawdlun';
$lang['thumbnail_height']      = 'Uchder bawdlun';
$lang['image_width']           = 'Lled delwedd';
$lang['image_height']          = 'Uchder delwedd';
$lang['cols']                  = 'Delweddau y rhes';
$lang['sort']                  = 'Sut i drefnu delweddau\'r oriel';
$lang['sort_o_file']           = 'trefnu gan enw ffeil';
$lang['sort_o_mod']            = 'trefnu gan ddyddiad ffeil';
$lang['sort_o_date']           = 'trefnu gan ddyddiad EXIF';
$lang['sort_o_title']          = 'trefnu gan deitl EXIF';
$lang['options']               = 'Opsiynau diofyn ychwanegol  oriel';
